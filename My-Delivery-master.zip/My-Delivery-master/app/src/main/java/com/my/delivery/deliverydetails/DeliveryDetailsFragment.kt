package com.my.delivery.deliverydetails

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.my.delivery.R
import com.my.delivery.deliverylist.model.Delivery
import com.my.delivery.deliverylist.storage.AppDatabase
import com.my.delivery.utils.UtilityHelper
import kotlinx.android.synthetic.main.fragment_delivery_details.*

class DeliveryDetailsFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_delivery_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //for creating home back
        val activity = activity as AppCompatActivity?
        activity!!.supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        val args = arguments
        val delivery:Delivery = args!!.getSerializable(getString(R.string.delivery)) as Delivery

        senderTv.text = delivery.route.start
        receiverTv.text = delivery.route.end
        context?.let { Glide.with(it).load(delivery.goodsPicture).into(ivGoods) }

        tvFees.text = UtilityHelper().formattedPrice(delivery)

        if (delivery.isFavorite) {
            tvAddToFavorite.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.star_big_on,0)
        }

        llAddToFavorite.setOnClickListener {
            val db = AppDatabase.getDatabase(this.context!!)
            val deliveryDao = db.deliveryDao()
            val data = deliveryDao.getDelivery(delivery.id)

            if (data.isFavorite) {
                data.isFavorite = false
                tvAddToFavorite.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.star_big_off,0)
            } else {
                data.isFavorite = true
                tvAddToFavorite.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.star_big_on,0)
            }

            deliveryDao.updateDelivery(data.isFavorite, data.id)

        }
    }
}