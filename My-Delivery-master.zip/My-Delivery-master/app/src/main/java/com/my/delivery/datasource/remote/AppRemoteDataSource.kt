package com.my.delivery.datasource.remote

import android.content.Context
import com.my.delivery.datasource.AppDataSource
import com.my.delivery.datasource.ApiInterface
import com.my.delivery.datasource.ApiClient
import com.my.delivery.deliverylist.model.Delivery
import com.my.delivery.utils.Logger
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class AppRemoteDataSource : AppDataSource {

    override fun getDeliveryList(
        offset: Int,
        limit: Int,
        listener: AppDataSource.DataSourceListener,
        applicationContext: Context
    ) {

        val apiService = ApiClient.getClient()!!.create(ApiInterface::class.java)
        val call = apiService.getDeliveries(offset, limit)

        call.enqueue(object : Callback<ArrayList<Delivery>> {
            override fun onResponse(call: Call<ArrayList<Delivery>>, response: Response<ArrayList<Delivery>>) {
                if (response.code() == 200) {

                    val deliverList = response.body()
                    deliverList?.let { listener.onSuccess(it) }
                    Logger.d("TAG", response.message())
                } else {
                    listener.onError(response.code().toString(),response.errorBody()!!.string())
                }
            }

            override fun onFailure(call: Call<ArrayList<Delivery>>, t: Throwable) {
                Logger.d("TAG", t.message.toString())
                listener.onError("0",t.printStackTrace().toString())
            }
        })
    }
}