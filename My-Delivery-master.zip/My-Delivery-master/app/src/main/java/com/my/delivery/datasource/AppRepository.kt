package com.my.delivery.datasource

import android.annotation.SuppressLint
import android.content.Context

class AppRepository(val dataSource: AppDataSource) : AppDataSource {


    companion object {

        @SuppressLint("StaticFieldLeak")
        private var INSTANCE: AppRepository? = null

        fun getInstance(dataSource: AppDataSource) =
            INSTANCE ?: synchronized(AppRepository::class.java) {
                INSTANCE ?: AppRepository(dataSource)
                    .also { INSTANCE = it }
            }

        /**
         * Forcefully create new instance
         */
        @JvmStatic
        fun destroyInstance() {
            INSTANCE = null
        }
    }

    override fun getDeliveryList(
        offset: Int,
        limit: Int,
        listener: AppDataSource.DataSourceListener,
        applicationContext: Context
    ) {
        dataSource.getDeliveryList(offset, limit, listener, applicationContext)
    }
}