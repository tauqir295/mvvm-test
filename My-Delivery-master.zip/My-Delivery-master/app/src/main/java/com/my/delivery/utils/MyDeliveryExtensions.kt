@file:JvmName("MyDeliveryUtils")

package com.my.delivery.utils

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager

fun Fragment.replaceWithNextFragment(
    containerID:Int,
    fragmentManager: FragmentManager?,
    fragment: Fragment,
    arguments: Bundle?,
    addToBackStack: Boolean = true
) {
    arguments.let {
        fragment.arguments = it
    }

    fragmentManager!!.beginTransaction().apply {
        replace(containerID, fragment)
        if (addToBackStack) {
            addToBackStack(fragment::class.simpleName)
        }
        commit()
    }

}