package com.my.delivery.deliverylist

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.my.delivery.datasource.AppDataSource
import com.my.delivery.datasource.AppRepository
import com.my.delivery.datasource.ErrorBean
import com.my.delivery.deliverylist.model.Delivery

class DeliveryListViewModel(private val repository: AppRepository) : ViewModel() {

    private val _deliveryList: MutableLiveData<ArrayList<Delivery>> = MutableLiveData()
    val deliveryList: LiveData<ArrayList<Delivery>> = _deliveryList
    private val inProgress = MutableLiveData<Boolean>()
    val errorBean : MutableLiveData<ErrorBean> = MutableLiveData()

    fun getDeliveryList(
        offset: Int,
        limit: Int,
        applicationContext: Context
    ): LiveData<ArrayList<Delivery>> {
        inProgress.value = true

        repository.getDeliveryList(offset, limit, object : AppDataSource.DataSourceListener {
            override fun onSuccess(data: Any) {
                inProgress.value = false
                _deliveryList.postValue(data as ArrayList<Delivery>)
            }

            override fun onError(errorCode: String, errorMessage: String) {
                inProgress.value = false
                errorBean.postValue(ErrorBean(errorCode, errorMessage))
            }
        }, applicationContext)

        // Return immutable list of deliveries
        return deliveryList
    }
}