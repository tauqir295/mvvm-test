package com.my.delivery.datasource

import java.io.Serializable

data class ErrorBean (
    val errorCode: String,
    val errorMessage: String
): Serializable