package com.my.delivery.deliverylist.storage

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.my.delivery.deliverylist.model.Route
import com.my.delivery.deliverylist.model.Sender


class Converters {
    private val gson = Gson()


    @TypeConverter
    fun toSender(json: String): Sender {
        val type = object : TypeToken<Sender>() {}.type
        return Gson().fromJson(json, type)
    }

    @TypeConverter
    fun toJson(sender: Sender): String {
        val type = object: TypeToken<Sender>() {}.type
        return Gson().toJson(sender, type)
    }

    @TypeConverter
    fun toRoute(json: String): Route {
        val type = object : TypeToken<Route>() {}.type
        return Gson().fromJson(json, type)
    }

    @TypeConverter
    fun toJson(route: Route): String {
        val type = object: TypeToken<Route>() {}.type
        return Gson().toJson(route, type)
    }

}