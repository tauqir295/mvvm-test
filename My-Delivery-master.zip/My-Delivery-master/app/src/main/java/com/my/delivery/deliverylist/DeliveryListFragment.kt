package com.my.delivery.deliverylist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.my.delivery.AppViewModelFactory
import com.my.delivery.BuildConfig
import com.my.delivery.R
import com.my.delivery.datasource.AppRepository
import com.my.delivery.datasource.local.AppLocalDataSource
import com.my.delivery.datasource.remote.AppRemoteDataSource
import com.my.delivery.deliverydetails.DeliveryDetailsFragment
import com.my.delivery.deliverylist.adapter.DeliveryRecyclerAdapter
import com.my.delivery.deliverylist.adapter.LoadMoreListener
import com.my.delivery.deliverylist.model.Delivery
import com.my.delivery.deliverylist.storage.AppDatabase
import com.my.delivery.deliverylist.storage.DeliveryDao
import com.my.delivery.general.manager.ConfigurationManager
import com.my.delivery.utils.Logger
import com.my.delivery.utils.replaceWithNextFragment
import kotlinx.android.synthetic.main.fragment_main.*

class DeliveryListFragment : Fragment(), DeliveryRecyclerAdapter.OnRecyclerItemClickListener, LoadMoreListener.OnLoadMoreListener {
    companion object {
        fun newInstance() = DeliveryListFragment()
    }

    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var viewModel: DeliveryListViewModel
    private lateinit var adapter: DeliveryRecyclerAdapter
    private var offset = 0
    private var limit = 0
    private var total = 0
    private var db:AppDatabase? = null
    private var deliveryDao:DeliveryDao? = null
    private lateinit var loadMoreListener : LoadMoreListener

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        db = AppDatabase.getDatabase(this.context!!)
        deliveryDao = db!!.deliveryDao()

        offset = ConfigurationManager.instance.featureConfiguration!!.offset
        limit = ConfigurationManager.instance.featureConfiguration!!.limit

        initView()

    }

    private fun initView() {

        //for creating home back
        val activity = activity as AppCompatActivity?
        activity!!.supportActionBar!!.setDisplayHomeAsUpEnabled(false)

        adapter = DeliveryRecyclerAdapter()
        adapter.setOnItemClickListener(this)
        layoutManager = LinearLayoutManager(this.context, RecyclerView.VERTICAL, false)
        rvDeliveries.layoutManager = layoutManager
        rvDeliveries.adapter = adapter


        setupViewModels()
        setupPagination()
        activity?.let {
            viewModel.getDeliveryList(offset, limit, it.applicationContext)
        }
    }

    private fun setupViewModels() {
        activity?.let {
            val repository = AppRepository(
                when (BuildConfig.FLAVOR_environment) {
                    "stub" -> AppLocalDataSource()
                    else -> AppRemoteDataSource()
                }
            )
            val factory = AppViewModelFactory.getInstance(repository)
            viewModel = ViewModelProviders.of(it, factory).get(DeliveryListViewModel::class.java)

            viewModel.deliveryList.observe(viewLifecycleOwner,
                Observer { deliveries ->
                    if (deliveries.size > 0){
                        total += ConfigurationManager.instance.featureConfiguration!!.next
                        this.offset = total + 1
                        this.limit = ConfigurationManager.instance.featureConfiguration!!.next

                        adapter.removeProgressView()
                        loadMoreListener.setLoaded()
                        saveInDB(deliveries)
                    } else {
                        adapter.removeProgressView()
                        loadMoreListener.setLoaded()
                        loadMoreListener.pauseScrollListener(false)
                    }

                })
        }

        handleAPIFail()
    }

    private fun setupPagination() {
        loadMoreListener = LoadMoreListener(layoutManager, this)
        loadMoreListener.setLoaded()
        rvDeliveries.addOnScrollListener(loadMoreListener)
    }

    private fun saveInDB(deliveries: ArrayList<Delivery>) {

        for (delivery in deliveries) {
            deliveryDao!!.insertAll(delivery)
        }
        val list = deliveryDao!!.getAllDeliveries().asList().toMutableList()

        adapter.addDeliveryList(deliveries)
    }

    override fun onItemClick(
        item: View?,
        delivery: Delivery
    ) {
        Logger.d("DeliveryListFragment", "item clicked")

        val bundle = Bundle()
        bundle.putSerializable(getString(R.string.delivery), delivery)

        replaceWithNextFragment(
            this.id, fragmentManager, DeliveryDetailsFragment(), bundle, true
        )
    }

    override fun onLoadMore() {
        adapter.addProgressView()
        activity?.let {
            viewModel.getDeliveryList(offset, limit, it.applicationContext)
        }
    }

    private fun handleAPIFail() {
        viewModel.errorBean.observe(this,
            Observer { errorBean ->
                adapter.removeProgressView()
                loadMoreListener.setLoaded()
                loadMoreListener.pauseScrollListener(false)

                AlertDialog.Builder(context!!)
                    .setTitle("API Failed")
                    .setMessage("Something went wrong.")
                    .setPositiveButton("OK") { dialog, id ->
                        dialog.dismiss()
                    }
                    .setCancelable(false)
                    .show()

            })
    }
}