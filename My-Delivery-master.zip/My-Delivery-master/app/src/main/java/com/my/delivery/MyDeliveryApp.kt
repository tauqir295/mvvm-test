package com.my.delivery

import android.app.Application
import com.my.delivery.general.helper.AppAssetHelper
import com.my.delivery.general.manager.ConfigurationManager
import com.my.delivery.utils.Logger
import java.io.IOException

class MyDeliveryApp : Application() {
    private val TAG = Application::class.java.simpleName

    override fun onCreate() {
        super.onCreate()

        setAppConfiguration()
    }

    private fun setAppConfiguration() {

        try {
            Logger.d(TAG, "Setting up config")

            ConfigurationManager.instance.apiConfiguration = AppAssetHelper(this).getAPIConfiguration(BuildConfig.FLAVOR_country)

            ConfigurationManager.instance.featureConfiguration = AppAssetHelper(this).getFeatureConfiguration(BuildConfig.FLAVOR_country)

        } catch (e:IOException) {
            e.message?.let { Logger.e(TAG, it) }

        }

    }


}