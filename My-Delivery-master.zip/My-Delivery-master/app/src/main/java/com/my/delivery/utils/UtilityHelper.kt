package com.my.delivery.utils

import com.my.delivery.deliverylist.model.Delivery
import java.text.NumberFormat

@Suppress("RECEIVER_NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class UtilityHelper {

    fun formattedPrice(delivery: Delivery) : String{
        val deliveryFee = delivery.deliveryFee
        val surcharge = delivery.surcharge

        val format = NumberFormat.getCurrencyInstance()
        val surchargeVal = format.parse(surcharge)
        val deliveryFeeVal = format.parse(deliveryFee)

        val addedVal = surchargeVal.toFloat() + deliveryFeeVal.toFloat()

        return String.format("$%.2f", addedVal)
    }
}