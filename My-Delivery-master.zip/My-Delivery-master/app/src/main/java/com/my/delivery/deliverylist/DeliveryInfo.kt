package com.my.delivery.deliverylist

import com.my.delivery.AppBaseModelInfo

data class DeliveryInfo(val id: Long, val deliveryAddress: String) : AppBaseModelInfo