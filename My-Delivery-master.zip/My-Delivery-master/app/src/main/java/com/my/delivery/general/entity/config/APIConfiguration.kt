package com.my.delivery.general.entity.config

data class APIConfiguration(
    val host: String
)