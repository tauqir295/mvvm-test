package com.my.delivery.general.entity.config

data class FeatureConfiguration(
    val offset: Int,
    val limit: Int,
    val next: Int
)