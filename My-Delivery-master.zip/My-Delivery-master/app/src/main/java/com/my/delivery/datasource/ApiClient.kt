package com.my.delivery.datasource

import com.my.delivery.general.manager.ConfigurationManager
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Retrofit



class ApiClient {

    companion object {
        private val BASE_URL = "http://mock-api-mobile.dev.lalamove.com"
        private var retrofit: Retrofit? = null

        fun getClient(): Retrofit? {

            if (retrofit == null) {
                retrofit = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return this.retrofit
        }
    }

}