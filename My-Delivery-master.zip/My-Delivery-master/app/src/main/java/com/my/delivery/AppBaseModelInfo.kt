package com.my.delivery

/**
 * Marker interface to limit the data type of modal classes to be used into application.
 * Either for serialisation or data sharing
 */
interface AppBaseModelInfo{}