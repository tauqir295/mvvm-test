package com.my.delivery.datasource.local

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.my.delivery.datasource.AppDataSource
import com.my.delivery.deliverylist.model.Delivery
import com.my.delivery.general.helper.FileHelper

class AppLocalDataSource : AppDataSource {

    override fun getDeliveryList(
        offset: Int,
        limit: Int,
        listener: AppDataSource.DataSourceListener,
        applicationContext: Context
    ) {
        val fileName = "stub.json"
        val jsonStr = FileHelper.readJSONFromAsset(applicationContext, fileName)
        val typeToken = object : TypeToken<ArrayList<Delivery>>() {}.type
        val data = Gson().fromJson<ArrayList<Delivery>>(jsonStr, typeToken)

        listener.onSuccess(data)
    }
}