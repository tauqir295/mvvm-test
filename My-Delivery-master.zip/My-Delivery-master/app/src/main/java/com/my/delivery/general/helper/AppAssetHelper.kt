package com.my.delivery.general.helper

import android.content.Context
import com.google.gson.Gson
import com.my.delivery.general.entity.config.APIConfiguration
import com.my.delivery.general.entity.config.FeatureConfiguration

class AppAssetHelper (private val context: Context) {

    fun getAPIConfiguration (country:String):APIConfiguration {

        val fileName = "$country/apiConfig.json"
        return Gson().fromJson(FileHelper.readJSONFromAsset(context, fileName),
            APIConfiguration::class.java)
    }

    fun getFeatureConfiguration (country:String):FeatureConfiguration {

        val fileName = "$country/feature.json"
        return Gson().fromJson(FileHelper.readJSONFromAsset(context, fileName),
            FeatureConfiguration::class.java)
    }
}