package com.my.delivery

import com.my.delivery.datasource.AppRepository
import com.my.delivery.deliverylist.DeliveryListViewModel
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.internal.stubbing.answers.ThrowsException
import org.mockito.junit.MockitoJUnitRunner


@RunWith(MockitoJUnitRunner::class)
class DeliveryListViewModelTest {

    @Mock
    private val application: MyDeliveryApp? = null
    private var viewModel: DeliveryListViewModel? = null

    @Mock
    private val repository: AppRepository? = null

    @Before
    fun setUp() {
        /* test actual method */
        viewModel = Mockito.spy( DeliveryListViewModel(repository!!))
    }

    @After
    fun tearDown() {
    }

    @Test
    fun getDeliveryList() {
        viewModel!!.getDeliveryList(0, 2, application!!.applicationContext)
    }
}