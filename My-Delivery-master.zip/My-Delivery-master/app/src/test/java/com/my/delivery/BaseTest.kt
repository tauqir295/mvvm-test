package com.my.delivery

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.my.delivery.deliverylist.model.Delivery
import com.my.delivery.general.helper.FileHelper


open class BaseTest {

    fun getDeliveryList(context: Application): List<Delivery> {
        val fileName = "stub.json"
        val jsonStr = FileHelper.readJSONFromAsset(ApplicationProvider.getApplicationContext(), fileName)
        val typeToken = object : TypeToken<ArrayList<Delivery>>() {}.type
        return Gson().fromJson<List<Delivery>>(jsonStr, typeToken)
    }

}