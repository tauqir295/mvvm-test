package com.my.delivery

import android.app.Application
import com.my.delivery.deliverylist.adapter.DeliveryRecyclerAdapter
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DeliveryRecyclerAdapterTest : BaseTest(){

    private var deliveryRecyclerAdapter:DeliveryRecyclerAdapter? = null

    @Mock
    private lateinit var context: Application

    @Before
    fun setUp() {
        //application = mock(MyDeliveryApp::class.java)
        MockitoAnnotations.initMocks(this)
        deliveryRecyclerAdapter = Mockito.spy(DeliveryRecyclerAdapter::class.java)
    }

    @Test
    fun testNumberOfItems() {
        val list = getDeliveryList(context)

        deliveryRecyclerAdapter!!.addDeliveryList(list)
        Assert.assertEquals(deliveryRecyclerAdapter!!.itemCount, 10)

        javaClass.classLoader!!.getResource("test.json")
    }

}